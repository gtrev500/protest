<script>
  import ProtestDetail from '$lib/components/ProtestDetail.svelte';
</script>

<svelte:head>
  <title>Protest Details | Protest Tracker</title>
</svelte:head>

<ProtestDetail />