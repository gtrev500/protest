<script>
  import ProtestForm from '$lib/components/ProtestForm.svelte';
</script>

<svelte:head>
  <title>Submit a Protest | Protest Tracker</title>
</svelte:head>

<ProtestForm />