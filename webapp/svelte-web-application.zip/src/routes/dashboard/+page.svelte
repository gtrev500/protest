<script>
  import ProtestDashboard from '$lib/components/ProtestDashboard.svelte';
</script>

<svelte:head>
  <title>Dashboard | Protest Tracker</title>
</svelte:head>

<ProtestDashboard />